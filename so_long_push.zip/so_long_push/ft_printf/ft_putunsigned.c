/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putunsigned.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/21 13:00:13 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/22 09:57:39 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	print_unsigned(unsigned int a)
{
	int	count;

	count = 0;
	if (a / 10 == 0)
	{
		count += ft_putchar(a + '0');
	}
	else
	{
		count += print_unsigned(a / 10);
		count += ft_putchar((a % 10) + '0');
	}
	return (count);
}

int	ft_putunsigned(unsigned int n)
{
	int	count;

	count = 0;
	if (n == 0)
	{
		ft_putchar('0');
		return (1);
	}
	count += print_unsigned(n);
	return (count);
}
