/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_puthex.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/21 11:04:30 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/22 09:59:34 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	hex_length(unsigned	int num)
{
	int	count;

	count = 0;
	while (num != 0)
	{
		count++;
		num = num / 16;
	}
	return (count);
}

static void	ft_puthex(unsigned int num, const char c)
{
	if (num >= 16)
	{
		ft_puthex(num / 16, c);
		ft_puthex(num % 16, c);
	}
	else
	{
		if (num <= 9)
			ft_putchar((num + '0'));
		else
		{
			if (c == 'x')
				ft_putchar((num - 10 + 'a'));
			if (c == 'X')
				ft_putchar((num - 10 + 'A'));
		}
	}
}

int	ft_print_hex(unsigned int num, const char c)
{
	if (num == 0)
		return (write(1, "0", 1));
	else
		ft_puthex(num, c);
	return (hex_length(num));
}
