/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/20 16:51:15 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/22 10:16:35 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	check_format(char variadic, va_list list)
{
	int	count;

	count = 0;
	if (variadic == 'c')
		count += ft_putchar(va_arg(list, int));
	else if (variadic == 's')
		count += ft_putstr(va_arg(list, char *));
	else if (variadic == 'p')
		count += ft_print_ptr(va_arg(list, unsigned long long));
	else if (variadic == 'd' || variadic == 'i')
		count += ft_putnbr(va_arg(list, int));
	else if (variadic == 'u')
		count += ft_putunsigned(va_arg(list, unsigned int));
	else if (variadic == 'x' || variadic == 'X')
		count += ft_print_hex(va_arg(list, unsigned int), variadic);
	else if (variadic == '%')
		count += ft_putchar('%');
	return (count);
}

int	ft_printf(const char *format, ...)
{
	va_list	list;
	int		count;

	va_start(list, format);
	count = 0;
	while (*format)
	{
		if (*format == '%')
			count = count + check_format(*(++format), list);
		else
			count = count + write(1, format, 1);
		++format;
	}
	return (count);
}
