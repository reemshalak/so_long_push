/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/21 10:25:39 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/21 13:03:42 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	positif_print(int a)
{
	int	count;

	count = 0;
	if (a / 10 == 0)
	{
		count += ft_putchar(a + '0');
	}
	else
	{
		count += positif_print(a / 10);
		count += ft_putchar((a % 10) + '0');
	}
	return (count);
}

int	ft_putnbr(int n)
{
	int	count;

	count = 0;
	if (n == -2147483648)
	{
		count += ft_putchar('-');
		count += ft_putchar('2');
		n = 147483648;
	}
	if (n == 0)
	{
		ft_putchar('0');
		return (1);
	}
	if (n < 0)
	{
		count += ft_putchar('-');
		count += positif_print(-n);
	}
	else
		count += positif_print(n);
	return (count);
}
