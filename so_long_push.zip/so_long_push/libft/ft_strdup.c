/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 14:10:12 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/21 09:56:34 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *src)
{
	unsigned int	i;
	char			*src_copy;
	int				size;

	size = ft_strlen(src) + 1 ;
	src_copy = (char *)malloc(sizeof(char) * (size));
	i = 0;
	if (!src_copy)
		return (NULL);
	else
	{
		while (src[i] != '\0')
		{
			src_copy[i] = src[i];
			i++;
		}
		src_copy[i] = '\0';
	}
	return (src_copy);
}
