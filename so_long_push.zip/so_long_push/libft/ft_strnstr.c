/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 11:09:12 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/21 09:57:19 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *big, const char *little, size_t len)
{
	char	*str1;
	char	*str2;
	size_t	str2_len;

	str1 = (char *) big;
	str2 = (char *) little;
	str2_len = ft_strlen(str2);
	if (str2_len == 0)
		return (str1);
	while (*str1 && len >= str2_len)
	{
		if (ft_strncmp(str1, str2, str2_len) == 0)
			return (str1);
		str1++;
		len--;
	}
	return (0);
}
