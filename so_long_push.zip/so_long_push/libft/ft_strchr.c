/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 15:37:44 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/21 09:56:28 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *str, int c)
{
	if (c == '\0')
	{
		return ((char *)(str + ft_strlen(str)));
	}
	while (*str)
	{
		if (*str == (char) c)
		{
			return ((char *)(str));
		}
		str++;
	}
	return (NULL);
}
