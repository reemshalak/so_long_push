/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 15:51:16 by rchalak           #+#    #+#             */
/*   Updated: 2024/06/21 09:57:27 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(char *str, int c)
{
	char	*last;

	last = NULL;
	while (*str)
	{
		if (*str == (char) c)
		{
			last = str;
		}
		str++;
	}
	if ((char) c == '\0')
	{
		return (str);
	}
	return (last);
}
