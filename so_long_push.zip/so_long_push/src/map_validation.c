/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_validation.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 13:28:39 by rchalak           #+#    #+#             */
/*   Updated: 2024/07/27 17:21:12 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	valid_wall(void)
{
	int	i;

	i = 0;
	while (i < g_var.map.size.width)
	{
		if (g_var.map.data[0][i] != '1' || g_var.map.data[g_var.map.size.height
			- 1][i] != '1')
		{
			free_map();
			print_error_message("Invalid map\n");
		}
		i++;
	}
	i = 0;
	while (i < g_var.map.size.height)
	{
		if (g_var.map.data[i][0] != '1'
			|| g_var.map.data[i][g_var.map.size.width - 1] != '1')
		{
			free_map();
			print_error_message("Invalid map\n");
		}
		i++;
	}
}

void	is_rectangular(void)
{
	int	i;

	i = 0;
	while (i < g_var.map.size.height)
	{
		if ((int)ft_strlen(g_var.map.data[i]) != g_var.map.size.width)
		{
			free_map();
			print_error_message("not rectangular");
		}
		i++;
	}
}

void	contains_one_exit(void)
{
	int	exit_count;
	int	start_count;
	int	i;
	int	j;

	start_count = 0;
	exit_count = 0;
	i = -1;
	while (++i < g_var.map.size.height)
	{
		j = 0;
		while (j < g_var.map.size.width)
		{
			if (g_var.map.data[i][j] == 'E')
				exit_count++;
			if (g_var.map.data[i][j] == 'P')
				start_count++;
			j++;
		}
	}
	if (start_count != 1 || exit_count != 1)
	{
		free_map();
		print_error_message("error E or P");
	}
}

void	valid_collectable(void)
{
	int	i;
	int	j;
	int	collect;

	collect = 0;
	i = 0;
	while (i < g_var.map.size.height)
	{
		j = 0;
		while (j < g_var.map.size.width)
		{
			if (!is_valid(g_var.map.data[i][j]))
				print_error_message("not valid char");
			if (g_var.map.data[i][j] == 'C')
				collect++;
			j++;
		}
		i++;
	}
	if (collect == 0)
	{
		free_map();
		print_error_message("NO collectible");
	}
	g_var.game.count_collec = collect;
}

void	check_map(void)
{
	valid_wall();
	is_rectangular();
	valid_collectable();
	contains_one_exit();
	has_valid_path();
}
