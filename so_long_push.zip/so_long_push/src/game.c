/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   game.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 17:18:28 by rchalak           #+#    #+#             */
/*   Updated: 2024/07/27 17:23:51 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	init_position(void)
{
	int	i;
	int	j;

	i = 0;
	while (i < g_var.map.size.height)
	{
		j = 0;
		while (j < g_var.map.size.width)
		{
			if (g_var.map.data[i][j] == 'P')
			{
				g_var.img.pos.width = j;
				g_var.img.pos.height = i;
			}
			j++;
		}
		i++;
	}
}

void	print_steps(void)
{
	char	*str;
	char	*convert;

	convert = ft_itoa(g_var.game.count_steps);
	str = ft_strjoin("", convert);
	mlx_string_put(g_var.mlx, g_var.win, (g_var.img.pos.width * SPRITE_W) + 10,
		(g_var.img.pos.height * SPRITE_H) + 15, 0xFFFFFF, str);
	free(str);
	free(convert);
}
