/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   handle_movements.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 11:50:20 by rchalak           #+#    #+#             */
/*   Updated: 2024/07/27 17:17:15 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	check_collect(void)
{
	if (count_collec() == 0)
		free_exit("\e[32m\e[5m\e[1m🎉 CONGRATULATIONS 🎉\n!!!! You WON !!!!\e[0m\n");
	else
		ft_printf("\e[35m\e[1m ⚠️  Please, collect all the blood!!!\e[0m\n");
}

void	handle_left(void)
{
	if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width - 1] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width - 1] != '1')
		move_left();
}

void	handle_right(void)
{
	if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width + 1] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width + 1] != '1')
		move_right();
}

void	handle_down(void)
{
	if (g_var.map.data[g_var.img.pos.height + 1]
		[g_var.img.pos.width] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height + 1]
		[g_var.img.pos.width] != '1')
		move_down();
}

void	handle_up(void)
{
	if (g_var.map.data[g_var.img.pos.height - 1]
		[g_var.img.pos.width] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height - 1]
		[g_var.img.pos.width] != '1')
		move_up();
}
