/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   moves.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rchalak <rchalak@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 11:52:13 by rchalak           #+#    #+#             */
/*   Updated: 2024/07/27 16:14:14 by rchalak          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	move_left(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.width -= 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/bat_left.xpm";
}

void	move_right(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.width += 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/bat_right.xpm";
}

void	move_up(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.height -= 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/bat_right.xpm";
}

void	move_down(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.height += 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/bat_right.xpm";
}

void	moves(int key)
{
	if (key == KEY_A)
		handle_left();
	else if (key == KEY_D)
		handle_right();
	else if (key == KEY_S)
		handle_down();
	else if (key == KEY_W)
		handle_up();
}
